<template>
  <div class="hello">
    <div style="text-align: left; padding: 20px;">
      <router-link to="/">返回列表</router-link>
    </div>
    <div style="width: 500px;">
      <el-form ref="userform" :rules="rules" :model="form" label-width="120px">
        <el-form-item label="用户名：" prop="name">
          <el-input v-model="form.name"></el-input>
        </el-form-item>
        <el-form-item label="年龄：" prop="age">
          <el-input v-model.number="form.age"></el-input>
        </el-form-item>
        <el-form-item label="出生时间：" prop="createTime">
          <el-date-picker type="date" placeholder="选择日期" v-model="form.createTime" style="width: 100%;"></el-date-picker>
        </el-form-item>
        <el-form-item label="修改时间：" prop="updateTime">
          <el-date-picker type="date" placeholder="选择日期" v-model="form.updateTime" style="width: 100%;"></el-date-picker>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="submitForm()">保存</el-button>
          <el-button @click="resetForm()">重置</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import axios from 'axios'
import moment from 'moment'

export default {
  name: 'HelloWorld',
  data() {
    var checkAge = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('年龄不能为空'));
        }
        setTimeout(() => {
          if (!Number.isInteger(value)) {
            callback(new Error('请输入数字值'));
          } else {
            if (value < 18) {
              callback(new Error('必须年满18岁'));
            } else {
              callback();
            }
          }
        }, 1000);
      };
    return {
      formName: 'userform',
      form: {
        name: '',
        age: 0,
        createTime: '',
        updateTime: ''
      },
      rules: {
        name: [{ required: true, message: '请输入用户名', trigger: 'blur' },
            { min: 2, max: 5, message: '长度在 2 到 5 个字符', trigger: 'blur' }],
        age: [
          { required: true, message: '请输入年龄', trigger: 'blur' },
            { validator: checkAge, trigger: 'blur' }
          ],
        createTime: [{ type: 'date', required: true, message: '请选择时间', trigger: 'blur' }],
        updateTime: [{ type: 'date', required: true, message: '请选择时间', trigger: 'blur' }]
      }
    }
  },
  methods:{
      handleCallBack(response){
        if(response.status === 200){
          if(response.data.msg === 'success'){
            alert('操作成功！');
          }else{
            alert(response.data.msg);
          }
        }else{
          alert('操纵失败！');
        }
      },
      submitForm() {
        this.$refs[this.formName].validate((valid) => {
          if (valid) {
            let params = JSON.parse(JSON.stringify(this.form));
            params.createTime = moment(params.createTime).format('YYYY-MM-DD hh:mm:ss');
            params.updateTime = moment(params.updateTime).format('YYYY-MM-DD hh:mm:ss');
            axios.post('http://syyxdz.yule.com:8082/users/updateUserInfo', params)
              .then((response)=>{
                this.handleCallBack(response);
                this.$router.push({path: '/'});
              });
          } else {
            return false;
          }
        });
      },
      resetForm() {
        this.$refs[this.formName].resetFields();
      }
  },
  mounted() {
    // 每次请求携带cookies信息
    // axios.defaults.withCredentials = true
    // 为给定 ID 的 user 创建请求
    axios.get('http://syyxdz.yule.com:8082/users/getUserDetail', {
        params: {
          id: this.$route.query.id
        }
      })
      .then((response)=>{
        this.form.id = response.data.data[0].id;
        this.form.name = response.data.data[0].name;
        this.form.age = response.data.data[0].age;
        this.form.createTime = new Date(response.data.data[0].createTime);
        this.form.updateTime = new Date(response.data.data[0].updateTime);
      });
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
</style>
