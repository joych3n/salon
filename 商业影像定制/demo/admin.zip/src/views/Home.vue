<template>
  <div class="home">
    <div style="text-align: right; padding: 20px 30px;">
      <router-link to="/add">新增用户</router-link>
    </div>
    <List/>
  </div>
</template>

<script>
// @ is an alias to /src
import List from '@/components/List.vue'

export default {
  name: 'home',
  components: {
    List
  }
}
</script>
