var mysql = require("mysql");
var pool = mysql.createPool({
  host: 'localhost',//主机
  port: 3306,//端口号
  user: 'root',//MySQL认证用户名
  password: 'vipkid360',//MySQL认证用户密码
  database: 'syyxdz'  //数据库名称
});

function query(sql,callback){
  pool.getConnection(function(err,connection){
    connection.query(sql, function (err,rows) {
      callback(err,rows);
      connection.release();
    });
  });
}
exports.query = query;