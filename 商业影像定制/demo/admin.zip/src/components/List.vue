<template>
  <div class="hello">
    <div>
    <el-form :inline="true" :model="searchParams" class="demo-form-inline">
      <el-form-item label="用户名：">
        <el-input v-model="searchParams.name" placeholder="用户名"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="onSubmit">查询</el-button>
      </el-form-item>
    </el-form>
    </div>
     <el-table
      :data="tableData"
      style="width: 100%">
      <el-table-column
        prop="id"
        label="ID"
        width="60">
      </el-table-column>
      <el-table-column
        prop="name"
        label="姓名">
      </el-table-column>
      <el-table-column
        prop="age"
        label="年龄">
      </el-table-column>
      <el-table-column
        prop="createTime"
        label="创建时间">
      </el-table-column>
      <el-table-column
        prop="updateTime"
        label="更新时间">
      </el-table-column>
      <el-table-column
        fixed="right"
        label="操作"
        width="100">
        <template slot-scope="scope">
          <el-button @click="editRow(scope.row)" type="text" size="small">编辑</el-button>
          <el-button @click="deleteRow(scope.row)" type="text" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import axios from 'axios'
import moment from 'moment'

export default {
  name: 'HelloWorld',
  data() {
    return {
      tableData: [],
      searchParams: {
        name: ''
      }
    }
  },
  mounted() {
    this.getListData();
  },
  methods:{
    getListData(){
      axios.get('http://syyxdz.yule.com:8082/users/getUserList', {
        params: {
          name: this.searchParams.name
        }
      })
        .then((response)=>{
          if(response.data.data){
            response.data.data.forEach((e)=>{
              e.createTime = moment(e.createTime).format('YYYY-MM-DD hh:mm:ss');
              e.updateTime = moment(e.updateTime).format('YYYY-MM-DD hh:mm:ss');
            });
          }
          this.tableData = response.data.data || [];
        });
    },
    handleCallBack(response){
      if(response.status === 200){
        if(response.data.msg === 'success'){
          alert('操作成功！');
        }else{
          alert(JSON.stringify(response.data.msg));
        }
      }else{
        alert('操纵失败！');
      }
    },
    editRow(row){
      this.$router.push({path: '/detail?id=' + row.id});
    },
    deleteRow(row){
      axios.post('http://syyxdz.yule.com:8082/users/deleteUserInfo', row)
        .then((response)=>{
          this.handleCallBack(response);
          this.getListData();
        });
    },
    onSubmit(){
      this.getListData();
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
</style>
