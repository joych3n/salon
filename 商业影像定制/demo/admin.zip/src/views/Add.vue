<template>
  <div class="detail">
    <Create />
  </div>
</template>

<script>
// @ is an alias to /src
import Create from '@/components/Create.vue'

export default {
  name: 'detail',
  components: {
    Create
  }
}
</script>
