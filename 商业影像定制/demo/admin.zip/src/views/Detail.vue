<template>
  <div class="detail">
    <Form/>
  </div>
</template>

<script>
// @ is an alias to /src
import Form from '@/components/Form.vue'

export default {
  name: 'detail',
  components: {
    Form
  }
}
</script>
