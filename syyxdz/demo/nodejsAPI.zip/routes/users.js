var express = require('express');
var router = express.Router();

var db = require("../config/db");
const Unity = require('../tools/Unity');//Unity为一个工具类
const r = Unity.send;

/* 获取用户列表 */
router.get('/getUserList', function(req, res, next) {
    // 获取前台页面传过来的参数  
    let sql = 'select * from user order by id desc';
    let params = req.query || req.params;
    if(params.name){
        sql = 'select * from user where name like"%' +params.name+ '%" order by id desc';
    }
    db.query(sql, function (error, rows) {
        if (error) {
            res.send(r('', 200, 1, 'error'));
        } else {
            res.send(r(rows));
        }
    });
});

/* 获取用户详情 */
router.get('/getUserDetail', function(req, res, next) { 
    // 获取前台页面传过来的参数  
    let params = req.query || req.params;
    let sql = 'select * from user where id=' + params.id;
    db.query(sql, function (error, rows) {
        if (error) {
            res.send(r('', 200, 1, 'error'));
        } else {
            res.send(r(rows));
        }
    });
});

/* 更新用户信息 */
router.post('/updateUserInfo', function(req, res, next) { 
    // 获取前台页面传过来的参数  
    let params = req.body;
    let sql = 'update user set name="' + params.name + '", age=' + params.age + 
    ', createTime="' + params.createTime + '", updateTime="' + params.updateTime + '" where id=' + params.id;
    db.query(sql, function (error, rows) {
        if (error) {
            res.send(r(error, error.errno, 0, 'error'));
        } else {
            if(rows.affectedRows >= 1){
                res.send(r(true));
            }else{
                res.send(r(false));
            }
        }
    });
});

/* 新增用户 */
router.post('/insertUserInfo', function(req, res, next) { 
    // 获取前台页面传过来的参数  
    let params = req.body;
    let sql = 'insert into user(name, age, createTime, updateTime) values("' + params.name + '", ' + params.age + 
    ', "' + params.createTime + '", "' + params.updateTime + '")';
    db.query(sql, function (error, rows) {
        if (error) {
            res.send(r(error, error.errno, 0, 'error'));
        } else {
            if(rows.affectedRows >= 1){
                res.send(r(true));
            }else{
                res.send(r(false));
            }
        }
    });
});

/* 删除用户 */
router.post('/deleteUserInfo', function(req, res, next) { 
    // 获取前台页面传过来的参数  
    let params = req.body;
    let sql = 'delete from user where id=' + params.id;
    db.query(sql, function (error, rows) {
        if (error) {
            res.send(r(error, error.errno, 0, 'error'));
        } else {
            if(rows.affectedRows >= 1){
                res.send(r(true));
            }else{
                res.send(r(false));
            }
        }
    });
});

module.exports = router;
